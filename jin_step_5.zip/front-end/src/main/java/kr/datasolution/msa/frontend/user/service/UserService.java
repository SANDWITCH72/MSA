package kr.datasolution.msa.frontend.user.service;

import kr.datasolution.msa.frontend.user.dto.BoardDto;
import kr.datasolution.msa.frontend.user.dto.UserDto;
import kr.datasolution.msa.frontend.user.mapper.UserMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

import java.util.List;
import java.util.stream.Collectors;

/** 유저 관련 처리 Service Layer */
@Service
@RequiredArgsConstructor
@Slf4j
public class UserService {

    private final UserMapper userMapper;

    private WebClient webClient2 = WebClient.builder()
            .baseUrl("http://localhost:9090/user/")
            .build();

    /** 전체 등록된 사용자 리스트 조회 */
    public List<UserDto> getUserList() {

        return userMapper.findAll();
    }

    public List<UserDto> getClientUserList() {

        return webClient2.get()
                .uri("")
                .retrieve()
                .bodyToFlux(UserDto.class)
                .toStream()
                .collect(Collectors.toList());
    }

    /** 지정 사용자 상세 조회 */
    public UserDto getUser(String user_id) {

        return userMapper.findById(user_id);
    }

    public Mono<UserDto> getClientUser(String user_id) {

        return webClient2.get()
                .uri("/" + user_id)
                .retrieve()
                .bodyToMono(UserDto.class);
    }

    /** 사용자 등록 처리 */
    public void addUser(UserDto userDto) {
        int count = userMapper.save(userDto);
        log.info("User INSERT COUNT : {}", count);
    }

    public Void addClientUser(UserDto userDto) {

        return webClient2.post()
                .uri("")
                .bodyValue(userDto)
                .retrieve()
                .bodyToMono(Void.class)
                .block();
    }


    /** 사용자 수정 처리 */
    public void modUser(UserDto userDto) {
        int count = userMapper.update(userDto);
        log.info("User UPDATE COUNT : {}", count);
    }


    /** 사용자 삭제 처리 */
    public void removeUser(String user_id) {
        int count = userMapper.deleteById(user_id);
        log.info("User DELETE COUNT : {}", count);
    }

    public Void removeClientUser(String user_id) {

        return webClient2.delete()
                .uri("/" + user_id)
                .retrieve()
                .bodyToMono(Void.class)
                .block();

    }

}
