package kr.datasolution.msa.frontend.user.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

/**
 * 유저 DTO CLASS
 */
@Data
public class UserDto {

    /** 유저 ID */
    @Schema(description = "유저 ID")
    private int user_id;

    /** 유저 이름 */
    @Schema(description = "유저 이름")
    private String user_name;
    
}
