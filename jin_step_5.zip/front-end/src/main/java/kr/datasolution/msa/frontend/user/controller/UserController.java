package kr.datasolution.msa.frontend.user.controller;

import kr.datasolution.msa.frontend.user.dto.BoardDto;
import kr.datasolution.msa.frontend.user.dto.UserDto;
import kr.datasolution.msa.frontend.user.service.BoardService;
import kr.datasolution.msa.frontend.user.service.UserService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;


import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;

@Controller
@RequestMapping("/user")
@RequiredArgsConstructor
public class UserController {

    private final UserService userService;

    /** 전체 등록 게시물 리스트 조회 */
    @GetMapping("")
    public String getViewUserMain(ModelMap map) {
        map.put("list", userService.getClientUserList());
        return "user/main";
    }

    /** 지정 게시물 상세 조회 */
    @GetMapping("{user_id}")
    public String getViewUser(@PathVariable("user_id") String user_id,
                               ModelMap map) {
        BoardDto boardDto =  userService.getClientUserList(user_id).block();
        map.put("info", boardDto);

        return "user/info";
    }

    @GetMapping("new")
    public String getViewUserNew() {

        return "user/new";
    }

    /** 게시물 등록 처리 */
    @PostMapping("")
    public String addUser(@ModelAttribute UserDto userDto,
                           ModelMap map) {
        userService.addClientUser(userDto);

        return "redirect:/user";
    }

    /** 게시물 수정 화면 */
    @GetMapping("{user_id}/edit")
    public String getViewUserEdit(@PathVariable("user_id") String user_id,
                                   ModelMap map) {
        map.put("info", userService.getUser(user_id));
        return "user/edit";
    }


    /** 유저 수정 처리 */
    @PutMapping("{user_id}")
    public String modBoard(@PathVariable("user_id") String user_id,
                           @ModelAttribute UserDto userDto,
                           ModelMap map) {
        userDto.setUser_id(user_id);
        userService.modUser(userDto);

        return "redirect:/user/" + user_id;
    }

    /** 유저 삭제 처리 */
    @DeleteMapping("{user_id}")
    public String removeUser(@PathVariable("user_id") String user_id) {
        userService.removeClientUser(user_id);
        return "redirect:/user";
    }

}