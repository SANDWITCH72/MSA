package kr.datasolution.msa.frontend.user.service;

import kr.datasolution.msa.frontend.user.dto.BoardDto;
import kr.datasolution.msa.frontend.user.mapper.BoardMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;

/** 게시물 관련 처리 Service Layer */
@Service
@RequiredArgsConstructor
@Slf4j
public class BoardService {
    private final BoardMapper boardMapper;

    /** 전체 게시물 리스트 조회 */
    public List<BoardDto> getBoardList() {

        return boardMapper.findAll();
    }

    /** 지정 게시물 상세 조회 */
    public BoardDto getBoard(int id) {

        return boardMapper.findById(id);
    }

    /** 게시물 등록 처리 */
    public void addBoard(BoardDto boardDto) {
        int count = boardMapper.save(boardDto);
        log.info("BOARD INSERT COUNT : {}", count);
    }

    /** 게시물 수정 처리 */
    public void modBoard(BoardDto boardDto) {
        int count = boardMapper.update(boardDto);
        log.info("BOARD UPDATE COUNT : {}", count);
    }

    /** 게시물 삭제 처리 */
    public void removeBoard(int id) {
        int count = boardMapper.deleteById(id);
        log.info("BOARD DELETE COUNT : {}", count);
    }
}
