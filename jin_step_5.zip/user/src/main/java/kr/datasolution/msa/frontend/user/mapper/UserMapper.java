package kr.datasolution.msa.frontend.user.mapper;

import kr.datasolution.msa.frontend.user.dto.UserDto;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

/** 유저 DB TABLE 처리 Mapper Interface */
@Mapper
public interface UserMapper {

    /** 전체 등록된 사용자 리스트 조회 */
    List<UserDto> findAll();

    /** 지정 사용자 상세 조회 */
    UserDto findById(int userId);

    /** 사용자 등록 처리 */
    int save(UserDto userDto);

    /** 사용자 수정 처리 */
    int update(UserDto userDto);

    /** 사용자 삭제 처리 */
    int deleteById(int userId);
}
