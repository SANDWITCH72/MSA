package kr.datasolution.msa.frontend.user.controller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import kr.datasolution.msa.frontend.user.dto.UserDto;
import kr.datasolution.msa.frontend.user.service.UserService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;


/* 유저 관련 처리 Controller Layer */
@Tag(name = "USER API", description = "유저 API")
@RestController
@RequestMapping("/user")
@RequiredArgsConstructor
public class UserController {

    /** 유저 관련 처리 Service Layer 연결 */
    private final UserService userService;

    /** 게시물 목록 조회 화면 이동 */

    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Successful Operation"),
            @ApiResponse(responseCode = "404", description = "Not Found"),
            @ApiResponse(responseCode = "500", description = "Internal Server Error")
    })
    @Operation(summary = "유저 목록 조회",description = "유저를 조회합니다.")
    @GetMapping("")
    public List<UserDto> getUserListMain() {

        return userService.getUserList();
    }

    /** 유저 상세 조회 화면 이동 */
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Successful Operation"),
            @ApiResponse(responseCode = "404", description = "Not Found"),
            @ApiResponse(responseCode = "500", description = "Internal Server Error")
    })
    @Operation(summary = "유저 상세 조회",description = "유저 번호를 검색하며 해당 게시물을 조회합니다.")
    @GetMapping("{user_id}")
    public UserDto getUser(@PathVariable("user_id") int user_id) {

        return userService.getUser(user_id);
    }

    /** 유저 등록 처리 */
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Successful Operation",
                    content = @Content(schema = @Schema(implementation = UserDto.class))),
            @ApiResponse(responseCode = "404", description = "Not Found"),
            @ApiResponse(responseCode = "500", description = "Internal Server Error")
    })
    @Operation(summary = "유저 등록",description = "유저를 등록 합니다.")
    @PostMapping("")
    public void addUser(@RequestBody UserDto userDto) {

        userService.addUser(userDto);
    }
//
//     /** 유저 수정 처리 */
//    @ApiResponses(value = {
//            @ApiResponse(responseCode = "200", description = "Successful Operation",
//                    content = @Content(schema = @Schema(implementation = UserDto.class))),
//            @ApiResponse(responseCode = "404", description = "Not Found"),
//            @ApiResponse(responseCode = "500", description = "Internal Server Error")
//    })
//    @Operation(summary = "유저 수정",description = "유저 번호를 검색하며 해당 유저를 수정합니다.")
//    @PutMapping("{user_id}")
//    public void modUser(@PathVariable("user_id") String user_id, @RequestBody UserDto userDto) {
//
//        userService.getUser(user_id);
//        userService.modUser(userDto);
//
//    }
//
//    /** 유저 삭제 처리 */
//    @ApiResponses(value = {
//            @ApiResponse(responseCode = "200", description = "Successful Operation",
//                    content = @Content(schema = @Schema(implementation = UserDto.class))),
//            @ApiResponse(responseCode = "404", description = "Not Found"),
//            @ApiResponse(responseCode = "500", description = "Internal Server Error")
//    })
//    @Operation(summary = "유저 삭제",description = "유저 번호를 검색하며 해당 유저을 삭제합니다.")
//    @DeleteMapping("{user_id}")
//    public void removeUser(@PathVariable("user_id") String user_id) {
//
//        userService.removeUser(user_id);
//    }

}