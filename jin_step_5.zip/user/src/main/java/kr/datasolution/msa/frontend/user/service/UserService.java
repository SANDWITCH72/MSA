package kr.datasolution.msa.frontend.user.service;

import kr.datasolution.msa.frontend.user.dto.UserDto;
import kr.datasolution.msa.frontend.user.mapper.UserMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;

/** 유저 관련 처리 Service Layer */
@Service
@RequiredArgsConstructor
@Slf4j
public class UserService {

    private final UserMapper userMapper;

    /** 전체 등록된 사용자 리스트 조회 */
    public List<UserDto> getUserList() {

        return userMapper.findAll();
    }

    /** 지정 사용자 상세 조회 */
    public UserDto getUser(int user_id) {

        return userMapper.findById(user_id);
    }

//    /** 사용자 등록 처리 */
//    public void addUser(UserDto userDto) {
//        int count = userMapper.save(userDto);
//        log.info("User INSERT COUNT : {}", count);
//    }
//
//    /** 사용자 수정 처리 */
//    public void modUser(UserDto userDto) {
//        int count = userMapper.update(userDto);
//        log.info("User UPDATE COUNT : {}", count);
//    }
//
//
//    /** 사용자 삭제 처리 */
//    public void removeUser(int user_id) {
//        int count = userMapper.deleteById(user_id);
//        log.info("User DELETE COUNT : {}", count);
//    }

}
