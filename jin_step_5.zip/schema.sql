DROP TABLE IF EXISTS BOARD;

use mysql;

CREATE TABLE BOARD (
    ID BIGINT NOT NULL AUTO_INCREMENT,
    TITLE VARCHAR(50) NOT NULL,
    CONTENTS TEXT NOT NULL,
    REG_DT DATETIME NOT NULL,
    UPD_DT DATETIME,
    PRIMARY KEY (id)
);

create table USER (
    USER_ID VARCHAR(15) primary key not null,
    USER_NAME VARCHAR(10)
);

alter table BOARD add USER_ID VARCHAR(10);

alter table BOARD
    add foreign key (USER_ID)
        references USER (USER_ID)
        on delete cascade
        on update cascade;

select * from USER;